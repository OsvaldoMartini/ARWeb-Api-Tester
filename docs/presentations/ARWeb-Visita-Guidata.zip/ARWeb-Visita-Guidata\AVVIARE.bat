@echo off
rem Avvia la visita guidata ARWeb nel navigatore predefinito.
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 goto :python
where py >nul 2>nul
if %errorlevel%==0 goto :py
echo Python non trovato su questo computer.
echo Installare Python da https://www.python.org/downloads/ e riavviare AVVIARE.bat
pause
exit /b 1

:python
start "" http://localhost:8000/guida/index.html
python -m http.server 8000
exit /b 0

:py
start "" http://localhost:8000/guida/index.html
py -m http.server 8000
exit /b 0
